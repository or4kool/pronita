pronita.controller('homeController', ['$scope', function($scope){
	
	$scope.topnewHeader = 'top new';

	$scope.productCount = [0,1,2,3];

}]);